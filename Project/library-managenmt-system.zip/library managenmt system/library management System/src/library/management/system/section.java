
package library.management.system;

public class section {
    
    /*
    *   store the section name
    *
    *
    *   @var string
    */
    private String name;
    
    /*
    *   store number of book into the section
    *
    *
    *   @var int
    */
    private int NumberOfBook;
    
    /*
    *   store the description of the section
    *
    *
    *   @var String
    */
    private String descriptionSection;
    
    /*
    *   store the serial number of the section must be unique
    *
    *
    *   @var int
    */
    private int serialNo;
    
    
    /*
    *   function set name of the new section
    *
    *
    *   @param .....
    *   @return .....
    */
    public void setName(){
        // to do ....
    }
    
    
    /*
    *   function get name of the new section
    *
    *
    *   @param .....
    *   @return .....
    */
    
    public void getName(){
        // to do ....
    }
    
    /*
    *   function set number of the book into the new section
    *
    *
    *   @param .....
    *   @return .....
    */
    public void setNumberOfBook(){
        // to do ....
    }
    
    
    /*
    *   function get number of the book into the new section
    *
    *
    *   @param .....
    *   @return .....
    */
    
    public void getNumberOfBook(){
        // to do ....
    }
    
    /*
    *   function set description of the new section
    *
    *
    *   @param .....
    *   @return .....
    */
    public void setDescription(){
        // to do ....
    }
    
    
    /*
    *   function get name of the new section
    *
    *
    *   @param .....
    *   @return .....
    */
    
    public void getDescription(){
        // to do ....
    }
    
    /*
    *   function set serial number of the new section must be unique
    *
    *
    *   @param .....
    *   @return .....
    */
    public void setSerialNo(){
        // to do ....
    }
    
    
    /*
    *   function get  serial number of the new section
    *
    *
    *   @param .....
    *   @return .....
    */
    
    public void getSerialNo(){
        // to do ....
    }
    
    
    /*
    *   function to search the section by name or id of the section
    *
    *
    *   @param .....
    *   @return .....
    */
    public void searchSection(){
        // to do ......
    }
    
    /*
    *   function to add new section 
    *
    *
    *   @param ....
    *   @return .....
    */
    public void addSection(){
        //to do .....
    }
    
    /*
    *   function to update section  by id
    *
    *
    *   @param ....
    *   @return .....
    */
    public void updateSection(){
        //to do .....
    }
    
    /*
    *   function to delete section  by id
    *
    *
    *   @param ....
    *   @return .....
    */
    public void deleteSection(){
        //to do .....
    }
    
    /*
    *   function to list the all section 
    *
    *
    *   @param ....
    *   @return .....
    */
    public void listSection(){
        //to do .....
    }
    
    
    
    
    
    
}
