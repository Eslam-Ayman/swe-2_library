
package library.management.system;

public class librarian {
    
    /*
    *   store name of librarian that are access now
    *
    *
    *   @var String
    */
    private String name;
    
    
    /*
    *   store phone number of librarian that are access now
    *
    *
    *   @var String
    */
    private String phoneNo;
    
    /*
    *   store salary of librarian that are access now
    *
    *
    *   @var double
    */
    private double salary;
    
    /*
    *   store the email
    *
    *
    *   @var String
    */
    private String email;
    
    /*
    *   store the address
    *
    *
    *   @var String
    */
    private String address;
    
    /*
    *   store the gender
    *
    *
    *   @var Boolean
    */
    private Boolean gender;
    
    /*
    *   store the ssn
    *
    *
    *   @var int
    */
    private int ssn;
    
    /*
    *   store the username
    *
    *
    *   @var String
    */
    private String username;
    
    /*
    *   store the password
    *
    *
    *   @var String
    */
    private String password;
    
    /*
    *   store the date of birth
    *
    *
    *   @var String
    */
    private String dateOfBirth;
    
    /*
    *   store the admin
    *
    *
    *   @var Boolean
    */
    private Boolean admin;
    
    
    /*
    *   function set the name
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setName(){
        //to do ...
    }
    
    /*
    *   function get the name
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getName(){
        //to do ...
    }
    
    /*
    *   function set the phone number
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setPhoneNo(){
        //to do ...
    }
    
    /*
    *   function get the phone number
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getPhoneNo(){
        //to do ...
    }
    
    /*
    *   function set the gender
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setGender(){
        //to do ...
    }
    
    /*
    *   function get the gender
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getGender(){
        //to do ...
    }
    
    /*
    *   function set the email
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setEmail(){
        //to do ...
    }
    
    /*
    *   function get the email
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getEmail(){
        //to do ...
    }
    
    /*
    *   function set the salary
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setSalary(){
        //to do ...
    }
    
    /*
    *   function get the salary
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getSalary(){
        //to do ...
    }
    
    /*
    *   function set the address
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setAddress(){
        //to do ...
    }
    
    /*
    *   function get the address
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getAddress(){
        //to do ...
    }
    
    /*
    *   function set the username
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setUsername(){
        //to do ...
    }
    
    /*
    *   function get the username
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getUsername(){
        //to do ...
    }
    
    /*
    *   function set the password
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setPassword(){
        //to do ...
    }
    
    /*
    *   function get the password
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getPassword(){
        //to do ...
    }
    
    /*
    *   function set the admin
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setAdmin(){
        //to do ...
    }
    
    /*
    *   function get the admin
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getAdmin(){
        //to do ...
    }
    
    /*
    *   function set the ssn
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setSsn(){
        //to do ...
    }
    
    /*
    *   function get the ssn
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getSsn(){
        //to do ...
    }
    
    /*
    *   function set the date of  birth
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void setDateOfBirth(){
        //to do ...
    }
    
    /*
    *   function get the date of  birth
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void getDateOfBirth(){
        //to do ...
    }
    
    /*
    *   function add new book into specific section 
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void addBook(){ 
        // to do ....
    }
    
    /*
    *   function update book into specific section 
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void updateBook(){ 
        // to do ....
    }
    
    /*
    *   function delete book by serial number  into specific section 
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void deleteBook(){ 
        // to do ....
    }
    
    /*
    *   function add new Librarian 
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void addLibrarian(){ 
        // to do ....
    }
    
    /*
    *   function update librarian by id  
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void updateLibrarian(){ 
        // to do ....
    }
    
    /*
    *   function delete librarian by id
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void deleteLibrarian(){ 
        // to do ....
    }
    
    /*
    *   function add new member
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void addMember(){ 
        // to do ....
    }
    
    /*
    *   function update member by id
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void updateMember(){ 
        // to do ....
    }
    
    /*
    *   function delete member by id
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void deleteMember(){ 
        // to do ....
    }
    
    /*
    *   function add new section
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void addSection(){ 
        // to do ....
    }
    
    /*
    *   function update section by id
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void updateSection(){ 
        // to do ....
    }
    
    /*
    *   function delete section bye id
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void deleteSection(){ 
        // to do ....
    }
    
    /*
    *   function for search book
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void searchBook(){ 
        // to do ....
    }
    
    /*
    *   function search member
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void searchMember(){ 
        // to do ....
    }
    
    /*
    *   function search section
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void searchSection(){ 
        // to do ....
    }
    
    /*
    *   function show the invoice
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void showInvoice(){ 
        // to do ....
    }
    
    /*
    *   function show invoice by amount
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void showInvoiceByAmount(){ 
        // to do ....
    }
    
    /*
    *   function for login librarian
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void login(){ 
        // to do ....
    }
    
    /*
    *   function to logout the librarian from the system
    *
    *
    *   @param ...  
    *   @return ...
    */
    public void logout(){ 
        // to do ....
    }
    
}
