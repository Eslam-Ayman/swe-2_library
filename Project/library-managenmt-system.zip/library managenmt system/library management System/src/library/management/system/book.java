
package library.management.system;

public class book {
    
    
    
    /*
    *   store serial number for each book
    *
    *   @var int
    */
    private int serialNo;
    
    
    /*
    *   function set serial number of the book must be unique
    *
    *
    *   @param .....
    *   @return .....
    */
    public void setSerialNo(){
        // to do ....
    }
    
    
    /*
    *   function get serial number of the book must be unique
    *
    *
    *   @param .....
    *   @return .....
    */
    
    public void getSerialNo(){
        // to do ....
    }
    
}
