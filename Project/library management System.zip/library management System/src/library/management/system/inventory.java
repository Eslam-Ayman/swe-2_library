
package library.management.system;


public class inventory {
    
    /*
    *   store the name of the inventory to store the section and the book
    *
    *
    *   @var string
    */
    private String name;
    
    /*
    *   store the number of the book into the inventory
    *
    *
    *   @var int
    */
    private int numberOfBook;
    
    /*
    *   store the number of the section into the inventory
    *
    *
    *   @var int
    */
    private int numberOfSection;
    
    /*
    *   function to add the new book into the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void addBook(){
        // to do .....
    }
    
    /*
    *   function to update the book into the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void updateBook(){
        // to do .....
    }
    
    /*
    *   function to delete the book from the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void deleteBook(){
        // to do .....
    }
    
    /*
    *   function to add the new section into the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void addSection(){
        // to do .....
    }
    
    /*
    *   function to update the section into the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void updateSection(){
        // to do .....
    }
    
    /*
    *   function to delete the section from the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void deleteSection(){
        // to do .....
    }
    
    /*
    *   function to list the all book into the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void listBook(){
        // to do .....
    }
    
    
    /*
    *   function to get the specific book from the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void getBook(){
        // to do .....
    }
    
    
    /*
    *   function to list all section from the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void listSection(){
        // to do .....
    }
    /*
    *   function to get a specific section from the inventory
    *
    *
    *   @param ...
    *   @return ....
    */
    public void getSection(){
        // to do .....
    }
}
