
package library.management.system;

public class member {
   
    
    /*
    * store type member
    *  
    * @var boolean 
    */
    private Boolean gender;
    
    /*
    * store date of birth of the member
    *  
    * @var String 
    */
    private String dateOfbirth;
    
    /*
    * store the ssn
    *  
    * @var int 
    */
    private int ssn; 
    
    /*
    * store the email of the memebr
    *  
    * @var int 
    */
    private String email;
    
    /*
    * store name member
    *  
    * @var String 
    */
    private String name;
    
    /*
    * store address member
    *  
    * @var String 
    */
    private String address;
    
    /*
    * store phone number of member
    *  
    * @var String 
    */
    private String phoneNo;
    
    
    /*
    *   function to set the name
    *
    * @param ....
    * @return ...
    */
    public void setName(){
        // to do ..
    }
    
    /*
    *   function to get the name
    *
    * @param ....
    * @return ...
    */
     public void getName(){
        // to do ..
    }
     /*
    *   function to set the email
    *
    * @param ....
    * @return ...
    */
    public void setEmail(){
        // to do ..
    }
    
    /*
    *   function to get the email
    *
    * @param ....
    * @return ...
    */
     public void getEmail(){
        // to do ..
    }
     
    /*
    *   function to set the ssn
    *
    * @param ....
    * @return ...
    */
    public void setSsn(){
        // to do ..
    }
    
    /*
    *   function to get the ssn
    *
    * @param ....
    * @return ...
    */
     public void getSsn(){
        // to do ..
    }
    
    /*
    *   function to set the address
    *
    * @param ....
    * @return ...
    */
    public void setAddress(){
        // to do ..
    }
    
    /*
    *   function to get the address
    *
    * @param ....
    * @return ...
    */
     public void getAddress(){
        // to do ..
    }
     
    /*
    *   function to set the gender
    *
    * @param ....
    * @return ...
    */
    public void setGender(){
        // to do ..
    }
    
    /*
    *   function to get the gender
    *
    * @param ....
    * @return ...
    */
     public void getGender(){
        // to do ..
    }
    
    /*
    *   function to set the phone number
    *
    * @param ....
    * @return ...
    */
    public void setPhoneNo(){
        // to do ..
    }
    
    /*
    *   function to get the phone number
    *
    * @param ....
    * @return ...
    */
     public void getPhoneNo(){
        // to do ..
    }
     /*
    *   function to set the date of birth
    *
    * @param ....
    * @return ...
    */
    public void setDateOfBirth(){
        // to do ..
    }
    
    /*
    *   function to get the date of birth
    *
    * @param ....
    * @return ...
    */
     public void getDateOfBirth(){
        // to do ..
    }
     
    /*
    *   function add new  book .....
    *
    * @param ....
    * @return ...
    */
    public void  addBook(){
        // to do .....
    }
       
    /*
    *   function update the  book .....
    *
    * @param ....
    * @return ...
    */
    public void  updateBook(){
        // to do .....
    }
    
    /*
    *   function delete the   book .....
    *
    * @param ....
    * @return ...
    */
    public void  deleteBook(){
        // to do .....
    }
    
    /*
    *   function search book .....
    *
    * @param ....
    * @return ...
    */
    public void  searchBook(){
        // to do .....
    }
    
    /*
    *   function pay fee  .....
    *
    * @param ....
    * @return ...
    */
    public void  payFee(){
        // to do .....
    }
    

    
}
