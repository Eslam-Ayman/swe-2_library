
package library.management.system;

public class invoice {
    
    /*
    *   store the date of the invoice
    *   
    *   @var String
    */
    private String date;
    
    /*
    *   store the total amount book into the invoice
    *   
    *   @var double
    */
    private double totalAmount;
    
    /*
    *   store the list of the book that member are buy it
    *   
    *   @var array book
    */
    private book[] book;
    
    /*
    *   store the name of the member
    *   
    *   @var String
    */
    private String memberName;
    
    /*
    *   function to generate the invoice .......
    *
    *
    *   @param .....
    *   @return .....
    */
    public void generateInvoice(){
        // to do ......
    }
    
    /*
    *   function to generate the invoice .......
    *
    *
    *   @param .....
    *   @return .....
    */
    public void generateInvoiceByAmount(){
        // to do ......
    }
    
}
