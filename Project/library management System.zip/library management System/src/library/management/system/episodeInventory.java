
package library.management.system;

public class episodeInventory {
    
    /*
    *   store the name 
    *
    *   @var string
    */ 
    private String name;
    
    /*
    *   store the number of the bool 
    *
    *   @var int
    */
    private int numberOfBook;
    
    /*
    *   store the description
    *
    *   @var string
    */
    private String description;
    
    /*
    *   store the price 
    *
    *   @var double
    */
    private double price;
    
    /*
    *   store the type 
    *
    *   @var string
    */
    private String type;
    
    /*
    *   store the author
    *
    *   @var string
    */
    private String author;
    
    /*
    *   store the number of the paper
    *
    *   @var int
    */
    private int numberOfPaper;
    
    /*
    *   store the publishing house
    *
    *   @var string
    */
    private String publishingHouse;
    
    /*
    *   function to set the name
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setName(){
        // to do .......
    }
    
    /*
    *   function to get the name
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getName(){
        // to do .......
    }
    
    /*
    *   function to set the author
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setAuthor(){
        // to do .......
    }
    
    /*
    *   function to get the author
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getAuthor(){
        // to do .......
    }
    
    
    /*
    *   function to set the price
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setPrice(){
        // to do .......
    }
    
    /*
    *   function to get the price
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getPrice(){
        // to do .......
    }
    
    /*
    *   function to set the description
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setDescription(){
        // to do .......
    }
    
    /*
    *   function to get the description
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getDescription(){
        // to do .......
    }
    
    /*
    *   function to set the number of paper
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setNumberOfPaper(){
        // to do .......
    }
    
    /*
    *   function to get the number of paper
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getNumberOfPaper(){
        // to do .......
    }
    
    
    /*
    *   function to set the type
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setType(){
        // to do .......
    }
    
    /*
    *   function to get the type
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getType(){
        // to do .......
    }
    
    
    /*
    *   function to set the publishing house
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setPublishingHouse(){
        // to do .......
    }
    
    /*
    *   function to get the publishing house
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getPublishingHouse(){
        // to do .......
    }
    
    
    /*
    *   function to set the number of the book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void setNumberOfBook(){
        // to do .......
    }
    
    /*
    *   function to get the number of the book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getNumberOfBook(){
        // to do .......
    }
    
    /*
    *   function to add new book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void addBook(){
        // to do .......
    }
    
    /*
    *   function to update the book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void updateBook(){
        // to do .......
    }
    
    /*
    *   function to delete book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void deleteBook(){
        // to do .......
    }
    
    /*
    *   function to list the all book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void listBook(){
        // to do .......
    }
    
    /*
    *   function to get a secific  book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void getBook(){
        // to do .......
    }
    
    /*
    *   function to search of the book
    *
    *   
    *   @param .....
    *   @return ....
    */
    public void searchBook(){
        // to do .......
    }
}
